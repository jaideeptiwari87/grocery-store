param(
    [Parameter(Mandatory = $true)] [string] $versionfilepath
)
$filepath = $versionfilepath
$match = Select-String -Path $filepath -Pattern "Version"
$versionnumber = $match.Line.Substring($match.Line.IndexOf("Version")+"Version".Length+2).Trim()
$version = $versionnumber+"-"+"Release"
Write-Host "##vso[task.setvariable variable=version]$version"
