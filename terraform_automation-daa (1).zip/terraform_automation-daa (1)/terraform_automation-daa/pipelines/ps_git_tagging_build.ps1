param(
    [Parameter(Mandatory = $true)] [string] $versionfilepath,
    [Parameter(Mandatory = $true)] [string] $commitid,
    [Parameter(Mandatory = $true)] [string] $branch

)

$filepath = $versionfilepath
$shortHash = $commitid.Substring(0, 7)               
       
if($branch.Contains("main") -or $branch.Contains("hotfix") ){
    $match = Select-String -Path $filepath -Pattern "Version"
    $versionnumber = $match.Line.Substring($match.Line.IndexOf("Version")+"Version".Length+2).Trim()
    git fetch --tags
    $tagcount = (git tag -l $versionnumber* | Measure-Object | Select-Object -ExpandProperty Count)+1
    $version = $versionnumber+"-"+"rc"+""+$tagcount+"-"+$shortHash
    }
git tag $version
git push origin $version
Write-Host "##vso[task.setvariable variable=version]$version"
